from pathlib import Path

from src.data_preprocessing import (
    load_ratings,
    build_interaction_matrix,
    print_dataset_statistics,
)
from src.matrix_factorization import MatrixFactorization


DATA_PATH = Path(__file__).parent / "data" / "sample_ratings.csv"


def main():
    print("Recommendation Engine — 25% Milestone")

    ratings = load_ratings(DATA_PATH)
    matrix, user_to_idx, item_to_idx = build_interaction_matrix(ratings)

    print_dataset_statistics(ratings, matrix)

    print("\n--- Training Initial Matrix Factorization Model ---")

    model = MatrixFactorization(
        n_factors=3,
        learning_rate=0.01,
        regularization=0.02,
        epochs=100,
        random_state=42,
    )

    model.fit(matrix)

    rmse = model.reconstruction_rmse(matrix)

    print(f"Latent factors: {model.n_factors}")
    print(f"Training epochs: {model.epochs}")
    print(f"Reconstruction RMSE: {rmse:.4f}")

    print("\nInitial 25% pipeline completed successfully.")


if __name__ == "__main__":
    main()
