# Recommendation Engine with Monitoring

## AI & ML Internship — Project 2 (25% Milestone)

A recommendation system built using **matrix factorization** on user-item rating data. This repository contains the initial 25% implementation of the project.

### Current Progress — 25%

- [x] Dataset structure and sample ratings
- [x] Data loading and validation
- [x] User/item ID encoding
- [x] User-item interaction matrix creation
- [x] Sparse-data statistics
- [x] Initial matrix-factorization model implemented from scratch
- [x] Basic RMSE evaluation
- [ ] Cold-start strategy
- [ ] Top-N recommendation API
- [ ] Monitoring and drift detection
- [ ] Web interface
- [ ] Deployment

### Technology Stack

Python, NumPy, Pandas, SciPy, Scikit-learn

### Project Structure

```text
recommendation-engine-with-monitoring/
├── data/
│   └── sample_ratings.csv
├── src/
│   ├── data_preprocessing.py
│   └── matrix_factorization.py
├── run.py
├── requirements.txt
└── README.md
```

### Dataset

A small sample ratings dataset is included so the 25% milestone can run without downloading external data. For the final version, it can be replaced with a larger public dataset such as MovieLens.

### How to Run

```bash
pip install -r requirements.txt
python run.py
```

The program loads and validates ratings, creates the sparse user-item matrix, reports sparsity statistics, trains an initial matrix-factorization model, and reports reconstruction RMSE.

### Planned Final Architecture

```text
User Ratings / Interactions
            ↓
      Data Pipeline
            ↓
   User-Item Matrix
            ↓
   Matrix Factorization
            ↓
 Recommendation Engine
            ↓
 Top-N Recommendations
            ↓
 Monitoring & Drift Detection
            ↓
      Web/API Layer
```

### Future Work

The next milestones will add cold-start handling, Top-N recommendations, recommendation quality metrics, monitoring, drift detection, and eventually a web/API layer.

> This repository intentionally represents the initial 25% milestone rather than claiming the complete project is finished.
