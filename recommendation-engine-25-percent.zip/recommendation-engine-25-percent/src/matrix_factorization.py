import numpy as np


class MatrixFactorization:
    # Basic matrix factorization using stochastic gradient descent.
    # The model approximates R by P @ Q.T.

    def __init__(
        self,
        n_factors: int = 3,
        learning_rate: float = 0.01,
        regularization: float = 0.02,
        epochs: int = 100,
        random_state: int = 42,
    ):
        self.n_factors = n_factors
        self.learning_rate = learning_rate
        self.regularization = regularization
        self.epochs = epochs
        self.random_state = random_state
        self.user_factors = None
        self.item_factors = None

    def fit(self, ratings_matrix):
        rng = np.random.default_rng(self.random_state)

        coo = ratings_matrix.tocoo()
        n_users, n_items = ratings_matrix.shape

        self.user_factors = rng.normal(
            0, 0.1, size=(n_users, self.n_factors)
        )
        self.item_factors = rng.normal(
            0, 0.1, size=(n_items, self.n_factors)
        )

        observations = list(zip(coo.row, coo.col, coo.data))

        for _ in range(self.epochs):
            rng.shuffle(observations)

            for user_idx, item_idx, rating in observations:
                prediction = np.dot(
                    self.user_factors[user_idx],
                    self.item_factors[item_idx],
                )
                error = rating - prediction

                user_vector = self.user_factors[user_idx].copy()
                item_vector = self.item_factors[item_idx].copy()

                self.user_factors[user_idx] += self.learning_rate * (
                    error * item_vector
                    - self.regularization * user_vector
                )

                self.item_factors[item_idx] += self.learning_rate * (
                    error * user_vector
                    - self.regularization * item_vector
                )

        return self

    def predict(self, user_idx: int, item_idx: int) -> float:
        if self.user_factors is None or self.item_factors is None:
            raise RuntimeError("Model must be fitted before prediction.")

        return float(
            np.dot(self.user_factors[user_idx], self.item_factors[item_idx])
        )

    def reconstruction_rmse(self, ratings_matrix) -> float:
        coo = ratings_matrix.tocoo()

        if coo.nnz == 0:
            return 0.0

        errors = []
        for user_idx, item_idx, rating in zip(
            coo.row, coo.col, coo.data
        ):
            prediction = self.predict(user_idx, item_idx)
            errors.append((rating - prediction) ** 2)

        return float(np.sqrt(np.mean(errors)))
