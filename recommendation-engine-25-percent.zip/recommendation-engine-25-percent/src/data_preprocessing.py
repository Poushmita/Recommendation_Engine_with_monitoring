import pandas as pd
from scipy.sparse import csr_matrix

REQUIRED_COLUMNS = {"user_id", "item_id", "rating"}


def load_ratings(path: str) -> pd.DataFrame:
    # Load and validate user-item ratings.
    df = pd.read_csv(path)

    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    df = df[["user_id", "item_id", "rating"]].dropna().copy()
    df["rating"] = pd.to_numeric(df["rating"], errors="coerce")
    df = df.dropna(subset=["rating"])

    if not df["rating"].between(1, 5).all():
        raise ValueError("Ratings must be between 1 and 5.")

    return df


def build_interaction_matrix(df: pd.DataFrame):
    # Convert IDs to integer indices and create a sparse matrix.
    users = sorted(df["user_id"].unique())
    items = sorted(df["item_id"].unique())

    user_to_idx = {user: idx for idx, user in enumerate(users)}
    item_to_idx = {item: idx for idx, item in enumerate(items)}

    rows = df["user_id"].map(user_to_idx)
    cols = df["item_id"].map(item_to_idx)

    matrix = csr_matrix(
        (df["rating"], (rows, cols)),
        shape=(len(users), len(items)),
        dtype=float,
    )

    return matrix, user_to_idx, item_to_idx


def print_dataset_statistics(df: pd.DataFrame, matrix) -> None:
    total_possible = matrix.shape[0] * matrix.shape[1]
    observed = matrix.nnz
    sparsity = 1 - (observed / total_possible)

    print("\n--- Dataset Statistics ---")
    print(f"Users: {matrix.shape[0]}")
    print(f"Items: {matrix.shape[1]}")
    print(f"Observed ratings: {observed}")
    print(f"Possible user-item pairs: {total_possible}")
    print(f"Sparsity: {sparsity:.2%}")
    print(f"Average rating: {df['rating'].mean():.2f}")
